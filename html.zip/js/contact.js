function jump_fb(){
    var winHandler = window.open('', '_blank');
    winHandler.location.href = 'https://www.facebook.com/profile.php?id=100009640625392';
}

function jump_twi(){
    var winHandler = window.open('', '_blank');
    winHandler.location.href = 'https://twitter.com/huangzuocesc';
}

function jump_ins(){
    var winHandler = window.open('', '_blank');
    winHandler.location.href = 'https://www.instagram.com/huangzuocesc/';
}

function jump_git(){
    var winHandler = window.open('', '_blank');
    winHandler.location.href = 'https://github.com/hz920120';
}

function jump_weibo(){
    var winHandler = window.open('', '_blank');
    winHandler.location.href = 'https://weibo.com/1172613352/profile?topnav=1&wvr=6';
}

function jump_wechat(){
    var winHandler = window.open('', '_blank');
    winHandler.location.href = '../images/wechat.png';
}