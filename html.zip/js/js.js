(function($) {
    /*------------------
    TYPED JS
--------------------*/
    $(".element").typed({
        strings: ["I'm Michael Owen", "Web Designer", "From Sydney"],
        typeSpeed: 10,
        loop:true,
        backDelay: 2000
    });
})(jQuery);